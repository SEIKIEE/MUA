package src.mua;

import java.util.ArrayList;
import java.util.Stack;

public class Interpreter {
    public static NameSpace NameSpace;
    public static Word Word;
    private static Stack<String> commandStack = new Stack<String>();

    Interpreter() {
        NameSpace = new NameSpace();  //initialize the namespace
        Word = new Word();
    }

    public static void initialize(String s) {
        //commandStack.clear();
        String[] command = s.split(" |\t");
        for (int i = 0; i < command.length; i++) {
            if (command[i].startsWith("//"))
                break;
            commandStack.push(command[i]);
        }
    }

    public static void readCommand() {
        NON_ENOUGH_PARAMETER:
        while (Main.scan.hasNext()) {
            String command = Main.scan.next();
            initialize(command);
            try {
                do {
                    boolean flag = false;
                    ArrayList<String> store = new ArrayList<>();
                    do {
                        store.add(commandStack.pop());
                    } while (!src.mua.Word.isReversedWord(store.get(store.size() - 1)));
                    int i = store.size() - 1;
                    switch (store.get(i)) {
                        case "make":
                            //make <word> <value> => store.size()>=3 => i>=2
                            if (i < 2) {
                                commandStack.push("make");
                                flag = true;
                                break;
                            }
                            Operator.make(store.get(--i), store.get(--i));
                            break;
                        case "thing":
                            //thing <word> => store.size()>=2 => i>=1
                            if (i < 1) {
                                commandStack.push("thing");
                                flag = true;
                                break;
                            }
                            Value v = Operator.thing(store.get(--i));
                            switch (v.type) {
                                case 1: //number
                                case 3: //boolean
                                    commandStack.push(v.value);
                                    break;
                                case 2: //word
                                    commandStack.push("\"" + v.value);
                                    break;
                                default:
                                    System.out.println("something wrong");
                                    break;
                            }
                            break;
                        case "erase":
                            //erase <word> => store.size()>=2 => i>=1
                            if (i < 1) {
                                commandStack.push("erase");
                                flag = true;
                                break;
                            }
                            Operator.erase(store.get(--i));
                            break;
                        case "isname":
                            //isname <word> => store.size()>=2 => i>=1
                            if (i < 1) {
                                commandStack.push("isname");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.isname(store.get(--i)) ? "true" : "false");
                            break;
                        case "print":
                            //print <value> => store.size()>=2 => i>=1
                            if (i < 1) {
                                commandStack.push("print");
                                flag = true;
                                break;
                            }
                            Operator.print(store.get(--i));
                            break;
                        case "read":
                            commandStack.push(Operator.read());
                            break;
                        case "add":
                            if (i < 2) {
                                commandStack.push("add");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.add(store.get(--i), store.get(--i), 1));
                            break;
                        case "sub":
                            if (i < 2) {
                                commandStack.push("sub");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.add(store.get(--i), store.get(--i), 2));
                            break;
                        case "mul":
                            if (i < 2) {
                                commandStack.push("mul");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.add(store.get(--i), store.get(--i), 3));
                            break;
                        case "div":
                            if (i < 2) {
                                commandStack.push("div");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.add(store.get(--i), store.get(--i), 4));
                            break;
                        case "mod":
                            if (i < 2) {
                                commandStack.push("mod");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.add(store.get(--i), store.get(--i), 5));
                            break;
                        case "eq":
                            if (i < 2) {
                                commandStack.push("eq");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.eq(store.get(--i), store.get(--i)));
                            break;
                        case "gt":
                            if (i < 2) {
                                commandStack.push("gt");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.gt(store.get(--i), store.get(--i)));
                            break;
                        case "lt":
                            if (i < 2) {
                                commandStack.push("lt");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.lt(store.get(--i), store.get(--i)));
                            break;
                        case "and":
                            if (i < 2) {
                                commandStack.push("and");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.and(store.get(--i), store.get(--i)));
                            break;
                        case "or":
                            if (i < 2) {
                                commandStack.push("or");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.or(store.get(--i), store.get(--i)));
                            break;
                        case "not":
                            if (i < 1) {
                                commandStack.push("not");
                                flag = true;
                                break;
                            }
                            commandStack.push(Operator.not(store.get(--i)));
                            break;
                        default:
                            break;
                    }
                    for (int j = --i; j > -1; j--)
                        commandStack.push(store.get(j));
                    if (flag) break;
                } while (!commandStack.isEmpty());
            } catch (Exception e) {
                //System.out.println(e.getMessage());
            }
        }
    }
}


