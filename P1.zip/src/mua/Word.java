package src.mua;

import java.util.HashMap;

public class Word {
    private static HashMap<String, Integer> reversedWord = new HashMap<>();

    public Word() {
        String[] operation = {
                "make", "thing", "erase", "isname", "print", "read",
                "add", "sub", "mul", "div", "mod",
                "eq", "gt", "lt",
                "and", "or", "not"
        };
        for (int i = 0; i < operation.length; i++) {
            reversedWord.put(operation[i], i);
        }
        operation = null;
    }

    public static boolean isReversedWord(String s) {
        return reversedWord.containsKey(s);
    }

    public static boolean isWord(String s) {
        if (s.startsWith("\"") == true) {
            if (!isReversedWord(s.substring(1))) {
                return true;
            } else return false;
        } else return false;
    }

    public static boolean isNumber(String s) {
        String reg = "^-?[0-9]+(.[0-9]+)?$";
        return s.matches(reg);
    }

    public static boolean isBoolean(String s) {
        if (s.equals("true") || s.equals("false"))
            return true;
        else return false;
    }

    public static boolean isBindValue(String s) {
        if (s.startsWith(":"))
            return true;
        else return false;
    }
}
