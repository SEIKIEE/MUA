package src.mua;

import java.util.HashMap;

public class NameSpace {
    private static HashMap<String, Value> valueMap;

    public NameSpace() {
        valueMap = new HashMap<String, Value>();
    }

    public void bindValue(String key, Value value) {
        valueMap.put(key, value);
    }

    public void unbindValue(String key) {
        if (valueMap.containsKey(key))
            valueMap.remove(key, valueMap.get(key));
    }

    public Value getValueOf(String key) {
        return valueMap.get(key);
    }

    public boolean isName(String key) {
        return valueMap.containsKey(key);
    }
}
