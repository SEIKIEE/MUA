package src.mua;

public class Operator {
    //make <name> <value> : 将value绑定到name上，绑定后的名字位于命名空间。此⽂文档中的基本操
    //作的名字不不能重新命名
    public static void make(String key, String value) throws Exception {
        /*if (!Word.isWord(key)) throw new Exception("word不对");
        key = key.substring(1);*/
        if (Word.isWord(key))
            key = key.substring(1);
        else if (Word.isBindValue(key)) {
            if (!Interpreter.NameSpace.isName(key.substring(1)))
                throw new Exception("名字不存在");
            else key = Interpreter.NameSpace.getValueOf(key.substring(1)).value;
        }

        if (Word.isBindValue(value)) {
            value = value.substring(1);
            //name exists
            if (Interpreter.NameSpace.isName(value)) {
                Interpreter.NameSpace.bindValue(key, new Value(Interpreter.NameSpace.getValueOf(value)));
            } else throw new Exception("名字不存在");
        } else if (Word.isNumber(value)) {
            Interpreter.NameSpace.bindValue(key, new Value(1, value));
        } else if (Word.isWord(value))
            Interpreter.NameSpace.bindValue(key, new Value(2, value.substring(1)));
        else if (Word.isBoolean(value))
            Interpreter.NameSpace.bindValue(key, new Value(3, value));
        else throw new Exception("make的value不正确，啥都不是");
    }

    //thing <name> :返回word所绑定的值
    public static Value thing(String key) throws Exception {
        if (Word.isWord(key))
            key = key.substring(1);
        else if (Word.isBindValue(key)) {
            key = key.substring(1);
            key = Interpreter.NameSpace.getValueOf(key).value;
        } else throw new Exception("thing的name不正确");
        if (!Interpreter.NameSpace.isName(key))
            throw new Exception("名字不存在");
        else {
            return Interpreter.NameSpace.getValueOf(key);
        }
    }

    //erase <name> :清除word所绑定的值
    public static void erase(String key) throws Exception {
        key = key.substring(1);
        if (!Interpreter.NameSpace.isName(key))
            throw new Exception("名字不存在");
        else Interpreter.NameSpace.unbindValue(key);
    }

    //isname <word> :返回word是否是⼀一个名字，true/false
    public static boolean isname(String key) {
        if (Word.isWord(key))
            return Interpreter.NameSpace.isName(key.substring(1));
        else if (Word.isBindValue(key)) {
            Value v = Interpreter.NameSpace.getValueOf(key.substring(1));
            if (v.type != 2)
                return false;
            else return Interpreter.NameSpace.isName(v.value);
        } else return false;
    }

    //print <value>
    public static void print(String key) throws Exception {
        if (Word.isBoolean(key))
            System.out.println(key);
        else if (Word.isWord(key))
            System.out.println(key.substring(1));
        else if (Word.isNumber(key))
            System.out.println(Double.valueOf(key));
        else if (Word.isBindValue(key)) {
            key = key.substring(1);
            if (!Interpreter.NameSpace.isName(key))
                throw new Exception("名字不存在");
            else {
                System.out.println(Interpreter.NameSpace.getValueOf(key).value);
            }
        } else throw new Exception("print的value错误");
    }

    //read :返回⼀一个从标准输⼊入读取的数字或字
    public static String read() {
        String string = Main.scan.next();
        if (Word.isBoolean(string) || Word.isNumber(string) || Word.isWord(string))
            return string;
        else return "\"" + string;
    }

    public static String add(String a, String b, int type) throws Exception {
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else a = Interpreter.NameSpace.getValueOf(a).value;
        }
        if (Word.isBindValue(b)) {
            b = b.substring(1);
            if (!Interpreter.NameSpace.isName(b))
                throw new Exception("不是个名字");
            else b = Interpreter.NameSpace.getValueOf(b).value;
        }
        if (Word.isWord(a)) a = a.substring(1);
        if (Word.isWord(b)) b = b.substring(1);
        if (Word.isNumber(a) && Word.isNumber(b)) {
            double p = Double.valueOf(a);
            double q = Double.valueOf(b);
            switch (type) {
                case 1:
                    return String.valueOf(p + q);
                case 2:
                    return String.valueOf(p - q);
                case 3:
                    return String.valueOf(p * q);
                case 4:
                    return String.valueOf(p / q);
                case 5:
                    return String.valueOf(p % q);
                default:
                    throw new Exception("没有这个运算");
            }
        } else throw new Exception("不可运算");
    }

    public static String and(String a, String b) throws Exception {
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(a);
                if (v.type == 1)
                    throw new Exception("非bool型数据");
                a = v.value;
            }
        }
        if (Word.isBindValue(b)) {
            b = b.substring(1);
            if (!Interpreter.NameSpace.isName(b))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(b);
                if (v.type == 1)
                    throw new Exception("非bool型数据");
                b = v.value;
            }
        }
        if (Word.isWord(a))
            a = a.substring(1);
        if (Word.isWord(b))
            b = b.substring(1);

        if ((!a.equals("true") && !a.equals("false")) || (!b.equals("true") && !b.equals("false")))
            throw new Exception("不可运算");
        if (a.equals(b))
            return a;
        else return "false";
    }

    public static String or(String a, String b) throws Exception {
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(a);
                if (v.type == 1)
                    throw new Exception("非bool型数据");
                a = v.value;
            }
        }
        if (Word.isBindValue(b)) {
            b = b.substring(1);
            if (!Interpreter.NameSpace.isName(b))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(b);
                if (v.type == 1)
                    throw new Exception("非bool型数据");
                b = v.value;
            }
        }
        if (Word.isWord(a))
            a = a.substring(1);
        if (Word.isWord(b))
            b = b.substring(1);

        if ((!a.equals("true") && !a.equals("false")) || (!b.equals("true") && !b.equals("false")))
            throw new Exception("不可运算");
        if (!a.equals(b))
            return "true";
        else if (a.equals("false"))
            return "false";
        else return "true";
    }

    public static String not(String a) throws Exception {
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else a = Interpreter.NameSpace.getValueOf(a).value;
        }
        if (Word.isWord(a))
            a = a.substring(1);
        if (a.equals("true"))
            return "false";
        else if (a.equals("false"))
            return "true";
        else
            throw new Exception("不可运算");
    }

    public static String eq(String a, String b) throws Exception {
        int aType = 0;
        int bType = 0;
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(a);
                a = v.value;
                aType = v.type;
            }
        } else if (Word.isWord(a)) {
            aType = 1;
            a = a.substring(1);
        } else if (Word.isNumber(a)) {
            aType = 0;
        } else if (Word.isBoolean(a)) {
            aType = 3;
        } else {
            throw new Exception("类型错误");
        }

        if (Word.isBindValue(b)) {
            b = b.substring(1);
            if (!Interpreter.NameSpace.isName(b))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(b);
                b = v.value;
                bType = v.type;
            }
        } else if (Word.isWord(b)) {
            bType = 1;
            b = b.substring(1);
        } else if (Word.isNumber(b)) {
            bType = 0;
        } else if (Word.isBoolean(b)) {
            bType = 3;
        } else {
            throw new Exception("类型错误");
        }
        if (aType == bType && aType == 0)
            return (Double.parseDouble(a) == Double.parseDouble(b)) ? "true" : "false";
        else
            return (a.equals(b) == true) ? "true" : "false";
    }

    public static String gt(String a, String b) throws Exception {
        int aType = 0;
        int bType = 0;
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(a);
                a = v.value;
                aType = v.type;
            }
        } else if (Word.isWord(a)) {
            aType = 1;
            a = a.substring(1);
        } else if (Word.isNumber(a)) {
            aType = 0;
        } else if (Word.isBoolean(a)) {
            aType = 3;
        } else {
            throw new Exception("类型错误");
        }

        if (Word.isBindValue(b)) {
            b = b.substring(1);
            if (!Interpreter.NameSpace.isName(b))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(b);
                b = v.value;
                bType = v.type;
            }
        } else if (Word.isWord(b)) {
            bType = 1;
            b = b.substring(1);
        } else if (Word.isNumber(b)) {
            bType = 0;
        } else if (Word.isBoolean(b)) {
            bType = 3;
        } else {
            throw new Exception("类型错误");
        }

        if (aType == bType && aType == 0)
            return (Double.parseDouble(a) > Double.parseDouble(b)) ? "true" : "false";
        else
            return (a.compareTo(b) > 0) ? "true" : "false";
    }

    public static String lt(String a, String b) throws Exception {
        int aType = 0;
        int bType = 0;
        if (Word.isBindValue(a)) {
            a = a.substring(1);
            if (!Interpreter.NameSpace.isName(a))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(a);
                a = v.value;
                aType = v.type;
            }
        } else if (Word.isWord(a)) {
            aType = 1;
            a = a.substring(1);
        } else if (Word.isNumber(a)) {
            aType = 0;
        } else if (Word.isBoolean(a)) {
            aType = 3;
        } else {
            throw new Exception("类型错误");
        }

        if (Word.isBindValue(b)) {
            b = b.substring(1);
            if (!Interpreter.NameSpace.isName(b))
                throw new Exception("不是个名字");
            else {
                Value v = Interpreter.NameSpace.getValueOf(b);
                b = v.value;
                bType = v.type;
            }
        } else if (Word.isWord(b)) {
            bType = 1;
            b = b.substring(1);
        } else if (Word.isNumber(b)) {
            bType = 0;
        } else if (Word.isBoolean(b)) {
            bType = 3;
        } else {
            throw new Exception("类型错误");
        }

        if (aType == bType && aType == 0)
            return (Double.parseDouble(a) < Double.parseDouble(b)) ? "true" : "false";
        else
            return (a.compareTo(b) < 0) ? "true" : "false";
    }
}
