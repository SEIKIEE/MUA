package src.mua;

import java.util.Scanner;

public class Operator {
    //make <name> <value> : 将value绑定到name上，绑定后的名字位于命名空间。此⽂文档中的基本操
    //作的名字不不能重新命名
    public static void make(Value key, Value value, NameSpace nameSpace) throws Exception {
        nameSpace.bindValue(key.value, value);
    }

    //thing <name> :返回word所绑定的值
    public static Value thing(Value key, NameSpace nameSpace) throws Exception {
        if (key.type != 2)
            throw new Exception("thing的name不正确");
        else if (!nameSpace.isName(key.value)) {
            throw new Exception("名字不存在");
        } else return nameSpace.getValueOf(key.value);
    }

    //erase <name> :清除word所绑定的值
    public static void erase(String key, NameSpace nameSpace) throws Exception {
        if (nameSpace.isName(key))
            throw new Exception("名字不存在");
        else nameSpace.unbindValue(key);
    }

    //isname <word> :返回word是否是⼀一个名字，true/false
    public static Value isname(Value key, NameSpace nameSpace) throws Exception {
        if (key.type != 2) {
            throw new Exception("isname的name不是word");
        }
        return new Value(3, String.valueOf(nameSpace.isName(key.value)));
    }

    //print <value>
    public static void print(Value key) throws Exception {
        System.out.println(key.value);
    }

    //read :返回⼀一个从标准输⼊入读取的数字或字
    public static Value read(Scanner scan) {
        String string = scan.next();
        if (Word.isBoolean(string))
            return new Value(3, string);
        else if (Word.isNumber(string))
            return new Value(1, string);
        else
            return new Value(2, string);
    }

    //readlist: 返回一个从标准输入读取的一行，构成一个表，行中每个以空格分隔部分是list的一个元素，元素的类型为字
    public static Value readlist(Scanner scan) {
        scan.nextLine();
        String result = scan.nextLine();
        return new Value(4, result.substring(1, result.length() - 1));
    }

    public static Value add(Value a, Value b, int type) throws Exception {
        if (a.type != b.type) {
            throw new Exception("运算类型不相同");
        }
        String result;
        if (a.type == 1 && b.type == 1) {
            double p = Double.valueOf(a.value);
            double q = Double.valueOf(b.value);
            switch (type) {
                case 1:
                    result = String.valueOf(p + q);
                    break;
                case 2:
                    result = String.valueOf(p - q);
                    break;
                case 3:
                    result = String.valueOf(p * q);
                    break;
                case 4:
                    result = String.valueOf(p / q);
                    break;
                case 5:
                    result = String.valueOf(p % q);
                    break;
                default:
                    throw new Exception("没有这个运算");
            }
            return new Value(1, result);
        } else throw new Exception("不可运算");
    }

    public static Value and(Value a, Value b) throws Exception {
        if ((!a.value.equals("true") && !a.value.equals("false")) || (!b.value.equals("true") && !b.value.equals("false")))
            throw new Exception("不可运算");
        if (a.value.equals(b.value))
            return a;
        else return new Value(3, "false");
    }

    public static Value or(Value a, Value b) throws Exception {
        if ((!a.value.equals("true") && !a.value.equals("false")) || (!b.value.equals("true") && !b.value.equals("false")))
            throw new Exception("不可运算");
        if (!a.value.equals(b.value))
            return new Value(3, "true");
        else if (a.equals("false"))
            return new Value(3, "false");
        else return new Value(3, "true");
    }

    public static Value not(Value a) throws Exception {
        if (a.value.equals("true"))
            return new Value(3, "false");
        else if (a.value.equals("false"))
            return new Value(3, "true");
        else
            throw new Exception("不可运算");
    }

    public static Value eq(Value a, Value b) throws Exception {
        String result;
        if (a.type == 1 || b.type == 1) {
            result = (Double.parseDouble(a.value) == Double.parseDouble(b.value)) ? "true" : "false";
        } else {
            result = (a.value.equals(b.value) == true) ? "true" : "false";
        }
        return new Value(3, String.valueOf(result));
    }

    public static Value gt(Value a, Value b) throws Exception {
        String result;
        if (a.type == 1 || b.type == 1) {
            result = (Double.parseDouble(a.value) > Double.parseDouble(b.value)) ? "true" : "false";
        } else {
            result = (a.value.compareTo(b.value) > 0) ? "true" : "false";

        }
        return new Value(3, result);
    }

    public static Value lt(Value a, Value b) throws Exception {
        String result;
        if (a.type == 1 || b.type == 1) {
            result = (Double.parseDouble(a.value) < Double.parseDouble(b.value)) ? "true" : "false";
        } else {
            result = (a.value.compareTo(b.value) < 0) ? "true" : "false";

        }
        return new Value(3, result);
    }

    //判断类型的函数：isnumber isword islist isbool isempty => 调用Word里写好的函数
    public static Value isnumber(Value temp) {
        return new Value(3, temp.type == 1 ? "true" : "false");
    }

    public static Value isword(Value temp) {
        return new Value(3, temp.type == 2 ? "true" : "false");

    }

    public static Value isbool(Value temp) {
        return new Value(3, temp.type == 3 ? "true" : "false");
    }

    public static Value islist(Value temp) {
        return new Value(3, temp.type == 4 ? "true" : "false");
    }

    public static Value isempty(Value temp) throws Exception {
        if (temp.type != 2 || temp.type != 4)
            throw new Exception("类型不对");
        return new Value(3, temp.value.equals("") ? "true" : "false");
    }

    //获得一个list 返回list的字面量
    public static String getList(String list, Scanner scan) {
        if (countChar(list, '[') == countChar(list, ']'))
            return list.substring(1, list.length() - 1);
        list += " " + scan.next();
        while (countChar(list, '[') != countChar(list, ']')) {
            list = list + " " + scan.next();
        }
        return list.substring(1, list.length() - 1);
    }

    private static int countChar(String s, char t) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == t) {
                count++;
            }
        }
        return count;
    }

    public static void output(NameSpace nameSpace, Value v) {
        nameSpace.bindValue("-output", v);
    }

    public static void stop(Scanner scan) {
        while (scan.hasNext())
            scan.nextLine();
    }

    public static void export(NameSpace nameSpace, Value v) {
        src.mua.Main.nameSpace.bindValue(v.value, nameSpace.getValueOf(v.value));
    }

    public static void doif(Value v1, Value v2, Value v3, NameSpace nameSpace) throws Exception {
        if (v1.type != 3) throw new Exception("if的条件不是bool");
        if (v1.value.equals("true")) {
            Scanner scan = new Scanner(v2.value);
            Interpreter.readCommand(scan, nameSpace);
        } else {
            Scanner scan = new Scanner(v3.value);
            Interpreter.readCommand(scan, nameSpace);
        }
    }

    public static Value function(String command, NameSpace nameSpace, Scanner scan) throws Exception {
        Value v1, v2;
        Value function = nameSpace.getValueOf(command);   //首先获得本地的函数
        if (function == null) function = Main.nameSpace.getValueOf(command);  //没有本地就获得全局的函数
        String functionCommand = function.value;
        Scanner newScanner = new Scanner(functionCommand);
        NameSpace newNameSpace = new NameSpace();   //局部变量
        v1 = Interpreter.readNextParameter(newScanner, nameSpace);  //参数表
        v2 = Interpreter.readNextParameter(newScanner, nameSpace);  //操作表
        newScanner = new Scanner(v2.value);
        String[] parameterList = v1.value.split(" |\t");
        for (int i = 0; i < parameterList.length; i++) {
            //参数绑定：参数的值来源于总体
            Value v = Interpreter.readNextParameter(scan, nameSpace);
            newNameSpace.bindValue(parameterList[i], v);
        }
        Interpreter.readCommand(newScanner, newNameSpace);
        return newNameSpace.getValueOf("-output");
    }
}
